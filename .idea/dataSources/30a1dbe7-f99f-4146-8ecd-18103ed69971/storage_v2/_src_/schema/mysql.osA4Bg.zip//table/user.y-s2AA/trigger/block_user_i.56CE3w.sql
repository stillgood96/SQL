create definer = rdsadmin@localhost trigger block_user_i
    before insert
    on user
    for each row
BEGIN
  DECLARE foo varchar(255);
  if new.User = "rdsadmin" then
    select `ERROR (RDS): CANNOT CREATE RDSADMIN USER` into foo from mysql.user;
  end if;

  if new.User = "rdsrepladmin" then
    select `ERROR (RDS): CANNOT CREATE RDSREPLADMIN USER` into foo from mysql.user;
  end if;

   if new.super_priv = 'Y' then
     select `ERROR (RDS): SUPER PRIVILEGE CANNOT BE GRANTED OR MAINTAINED` into foo from mysql.user;
   elseif new.shutdown_priv = 'Y' then
     select `ERROR (RDS): SHUTDOWN PRIVILEGE CANNOT BE GRANTED OR MAINTAINED. PLEASE USE RDS API` into foo from mysql.user;
   elseif new.file_priv = 'Y' then
     select `ERROR (RDS): FILE PRIVILEGE CANNOT BE GRANTED OR MAINTAINED` into foo from mysql.user;
   elseif new.repl_slave_priv = 'Y' then
     select `ERROR (RDS): REPLICA SLAVE PRIVILEGE CANNOT BE GRANTED OR MAINTAINED` into foo from mysql.user;
   elseif new.repl_client_priv = 'Y' then
       select `ERROR (RDS): REPLICA CLIENT PRIVILEGE CANNOT BE GRANTED OR MAINTAINED` into foo from mysql.user;
  end if; 
END;

